USE [SampleDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_updateEmployees]    Script Date: 6/7/2020 11:43:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_updateEmployees] 
(@dataTable EmployeeType READONLY)
	
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.


	update emp
set  emp.RemainderCount =dt.RemainderCount, emp.IsLinkAccessed=dt.IsLinkAccessed
from EmployeeDetails emp 
inner join  @dataTable dt on
emp.EmailId=dt.Email
	SET NOCOUNT ON;

   
END


GO


