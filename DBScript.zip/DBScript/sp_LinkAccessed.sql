USE [SampleDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_LinkAccessed]    Script Date: 6/7/2020 11:40:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_LinkAccessed]
	(@Email nvarchar(50))
	
AS
BEGIN
	
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update EmployeeDetails set IsLinkAccessed=1
	where EmailId=@Email

END
GO


