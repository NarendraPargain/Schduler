USE [SampleDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_getEmployee]    Script Date: 6/7/2020 11:40:29 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================  
-- Author:  <Author,,Name>  
-- Create date: <Create Date,,>  
-- Description: <Description,,>  
-- =============================================  
CREATE PROCEDURE [dbo].[sp_getEmployee]  
  
   
AS  
BEGIN  
   
 SET NOCOUNT ON;  
  
select Name,EmailId,IsLinkAccessed,RemainderCount from EmployeeDetails
where IsLinkAccessed=0
  
END  
GO


