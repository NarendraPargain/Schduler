USE [SampleDB]
GO

/****** Object:  Table [dbo].[EmployeeDetails]    Script Date: 6/7/2020 11:39:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[EmployeeDetails](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[EmailId] [nvarchar](50) NOT NULL,
	[IsLinkAccessed] [bit] NULL,
	[RemainderCount] [int] NULL,
 CONSTRAINT [PK_EmployeeDetails] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[EmployeeDetails] ADD  DEFAULT ((0)) FOR [IsLinkAccessed]
GO

ALTER TABLE [dbo].[EmployeeDetails] ADD  DEFAULT ((0)) FOR [RemainderCount]
GO


